/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { 
  Article, 
  Opportunity, 
  Resource, 
  BloomChallenge, 
  BloomOfTheWeek, 
  SiteSettings, 
  UserSubmission, 
  ContentReport, 
  Writer, 
  AuthUser,
  SubmissionType
} from './types';
import { 
  initializeStorage, 
  articleService, 
  opportunityService, 
  resourceService, 
  challengeService, 
  bloomOfWeekService, 
  submissionService, 
  reportService, 
  writerService, 
  settingsService, 
  authService,
  analyticsService
} from './services/storage';

// Components
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SearchModal } from './components/SearchModal';
import { ReportModal } from './components/ReportModal';
import { NotificationToast } from './components/NotificationToast';

// Views
import { HomeView } from './views/HomeView';
import { ExploreView } from './views/ExploreView';
import { BlogView } from './views/BlogView';
import { ArticleDetailView } from './views/ArticleDetailView';
import { OpportunitiesView } from './views/OpportunitiesView';
import { ResourcesView } from './views/ResourcesView';
import { ChallengesView } from './views/ChallengesView';
import { SubmitView } from './views/SubmitView';
import { AboutView } from './views/AboutView';
import { ContactView } from './views/ContactView';

// Admin CMS
import { AdminDashboard } from './views/admin/AdminDashboard';
import { AdminLoginModal } from './views/admin/AdminLoginModal';
import { AdminLoginView } from './views/admin/AdminLoginView';

export default function App() {
  // Application State initialized from URL pathname if applicable
  const [currentView, setCurrentView] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const p = window.location.pathname.replace(/^\//, '').toLowerCase();
      if (p === 'admin') return 'admin';
      if (p === 'explore') return 'explore';
      if (p === 'blog' || p === 'skills') return 'blog';
      if (p === 'opportunities') return 'opportunities';
      if (p === 'resources') return 'resources';
      if (p === 'challenges') return 'challenges';
      if (p === 'about') return 'about';
      if (p === 'contact') return 'contact';
      if (p === 'submit') return 'submit';
    }
    return 'home';
  });

  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [submitChallengeTitle, setSubmitChallengeTitle] = useState<string>('');
  
  // Data State
  const [articles, setArticles] = useState<Article[]>(() => articleService.getAll(true));
  const [opportunities, setOpportunities] = useState<Opportunity[]>(() => opportunityService.getAll(true));
  const [resources, setResources] = useState<Resource[]>(() => resourceService.getAll(true));
  const [challenges, setChallenges] = useState<BloomChallenge[]>(() => challengeService.getAll(true));
  const [bloomOfTheWeek, setBloomOfTheWeek] = useState<BloomOfTheWeek>(() => bloomOfWeekService.get());
  const [settings, setSettings] = useState<SiteSettings>(() => settingsService.get());
  const [submissions, setSubmissions] = useState<UserSubmission[]>(() => submissionService.getAll());
  const [reports, setReports] = useState<ContentReport[]>(() => reportService.getAll());
  const [writers, setWriters] = useState<Writer[]>(() => writerService.getAll());
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() => authService.getCurrentUser());

  // UI Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Report Modal Data
  const [reportModalData, setReportModalData] = useState<{
    isOpen: boolean;
    type: 'opportunity' | 'resource' | 'article';
    id: string;
    title: string;
  }>({
    isOpen: false,
    type: 'opportunity',
    id: '',
    title: ''
  });

  // Reload data from storage
  const refreshData = useCallback(() => {
    setArticles(articleService.getAll(true));
    setOpportunities(opportunityService.getAll(true));
    setResources(resourceService.getAll(true));
    setChallenges(challengeService.getAll(true));
    setBloomOfTheWeek(bloomOfWeekService.get());
    setSettings(settingsService.get());
    setSubmissions(submissionService.getAll());
    setReports(reportService.getAll());
    setWriters(writerService.getAll());
    setCurrentUser(authService.getCurrentUser());
  }, []);

  // Initialize storage and check session with backend
  useEffect(() => {
    initializeStorage();
    authService.checkSession().then(user => {
      if (user) {
        setCurrentUser(user);
      } else {
        setCurrentUser(null);
      }
      refreshData();
    });
  }, [refreshData]);

  // Synchronize document title and canonical meta for SEO
  useEffect(() => {
    let title = 'Debloom – Start where you are. Bloom from there.';
    let desc = 'A student-focused platform to discover opportunities, practical skills, verified resources, and challenges beyond the classroom.';

    if (currentView === 'article-detail' && selectedArticle) {
      title = `${selectedArticle.title} – Debloom 🌱`;
      desc = selectedArticle.excerpt;
    } else if (currentView === 'explore') {
      title = 'Explore Verified Opportunities & Guides – Debloom 🌱';
    } else if (currentView === 'opportunities') {
      title = 'Verified Student Opportunities & Scholarships – Debloom 🌱';
    } else if (currentView === 'resources') {
      title = 'Curated Student Tools & Free Learning Resources – Debloom 🌱';
    } else if (currentView === 'challenges') {
      title = 'Bloom Challenges: Practical Student Tasks – Debloom 🌱';
    } else if (currentView === 'blog' || currentView === 'skills') {
      title = 'Debloom Guides & Practical Skills – Debloom 🌱';
    } else if (currentView === 'submit') {
      title = 'Submit to Debloom: Opportunities, Tools & Challenge Entries 🌱';
    } else if (currentView === 'about') {
      title = 'About Debloom & Founder Debbie – Start Where You Are 🌱';
    } else if (currentView === 'admin') {
      title = 'Debloom CMS Admin Center';
    }

    document.title = title;
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', desc);
    }
  }, [currentView, selectedArticle]);

  // Global keyboard shortcuts (Cmd+K for search)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Navigation router
  const handleNavigate = (view: string, param?: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (typeof window !== 'undefined' && window.history) {
      const targetPath = view === 'home' ? '/' : `/${view}`;
      window.history.pushState(null, '', targetPath);
    }
    if (view === 'skills') {
      setCurrentView('blog');
      return;
    }
    if (view === 'article-detail' && param) {
      const art = articles.find(a => a.slug === param || a.id === param);
      if (art) {
        setSelectedArticle(art);
        setCurrentView('article-detail');
        return;
      }
    }
    setCurrentView(view);
  };

  const handleSelectArticle = (article: Article) => {
    setSelectedArticle(article);
    setCurrentView('article-detail');
  };

  const handleSelectChallenge = (challenge: BloomChallenge) => {
    setCurrentView('challenges');
  };

  const handleOpenSubmit = (challengeTitle?: string) => {
    setSubmitChallengeTitle(challengeTitle || '');
    setCurrentView('submit');
  };

  const handleOpenReportModal = (
    type: 'opportunity' | 'resource' | 'article',
    id: string,
    title: string
  ) => {
    setReportModalData({
      isOpen: true,
      type,
      id,
      title
    });
  };

  const handleSearchResult = (type: string, item: any) => {
    if (type === 'article') {
      handleSelectArticle(item);
    } else if (type === 'opportunity') {
      setCurrentView('opportunities');
    } else if (type === 'resource') {
      setCurrentView('resources');
    } else if (type === 'challenge') {
      setCurrentView('challenges');
    }
  };

  const handleLoginSuccess = (user: AuthUser) => {
    setCurrentUser(user);
    refreshData();
    setCurrentView('admin');
    setToastMessage(`Welcome to Debloom CMS, ${user.name}! 🌱`);
  };

  const handleLogout = () => {
    authService.logout();
    setCurrentUser(null);
    refreshData();
    setCurrentView('home');
    setToastMessage('Signed out of Debloom CMS.');
  };

  // If in admin view and user is authenticated
  if (currentView === 'admin' && currentUser) {
    return (
      <div className="min-h-screen bg-[#F7F5EE] flex flex-col font-sans">
        <AdminDashboard
          currentUser={currentUser}
          articles={articles}
          opportunities={opportunities}
          resources={resources}
          challenges={challenges}
          bloomOfTheWeek={bloomOfTheWeek}
          settings={settings}
          submissions={submissions}
          reports={reports}
          writers={writers}
          onRefreshData={refreshData}
          onLogout={handleLogout}
          onToast={(msg) => setToastMessage(msg)}
        />
        <NotificationToast 
          message={toastMessage} 
          onClose={() => setToastMessage(null)} 
        />
      </div>
    );
  }

  // Public Layout
  return (
    <div className="min-h-screen flex flex-col bg-[#FCFBF7] text-[#1F2421] selection:bg-[#E2ECE5] selection:text-[#163323]">
      
      {/* Site Header */}
      <Header
        currentView={currentView}
        onNavigate={handleNavigate}
        settings={settings}
        currentUser={currentUser}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAdminLogin={() => setIsAdminLoginOpen(true)}
        onLogoutAdmin={handleLogout}
      />

      {/* Main Page Body */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomeView
            articles={articles}
            opportunities={opportunities}
            resources={resources}
            challenges={challenges}
            settings={settings}
            onNavigate={handleNavigate}
            onSelectArticle={handleSelectArticle}
            onSelectChallenge={handleSelectChallenge}
          />
        )}

        {currentView === 'explore' && (
          <ExploreView
            articles={articles}
            opportunities={opportunities}
            resources={resources}
            challenges={challenges}
            onSelectArticle={handleSelectArticle}
            onSelectOpportunity={() => setCurrentView('opportunities')}
            onSelectResource={() => setCurrentView('resources')}
            onSelectChallenge={handleSelectChallenge}
            onOpenReportModal={handleOpenReportModal}
          />
        )}

        {currentView === 'blog' && (
          <BlogView
            articles={articles}
            onSelectArticle={handleSelectArticle}
          />
        )}

        {currentView === 'article-detail' && selectedArticle && (
          <ArticleDetailView
            article={selectedArticle}
            allArticles={articles}
            linkedChallenge={challenges.find(c => c.id === selectedArticle.bloomChallengeId)}
            onBack={() => setCurrentView('blog')}
            onSelectArticle={handleSelectArticle}
            onSelectChallenge={handleSelectChallenge}
            onOpenReportModal={handleOpenReportModal}
            onOpenSubmit={handleOpenSubmit}
            onToast={(msg) => setToastMessage(msg)}
          />
        )}

        {currentView === 'opportunities' && (
          <OpportunitiesView
            opportunities={opportunities}
            onOpenReportModal={handleOpenReportModal}
            onOpenSubmit={() => handleOpenSubmit()}
          />
        )}

        {currentView === 'resources' && (
          <ResourcesView
            resources={resources}
            onOpenReportModal={handleOpenReportModal}
            onOpenSubmit={() => handleOpenSubmit()}
          />
        )}

        {currentView === 'challenges' && (
          <ChallengesView
            challenges={challenges}
            bloomOfTheWeek={bloomOfTheWeek}
            onOpenSubmit={handleOpenSubmit}
            onSelectChallenge={handleSelectChallenge}
          />
        )}

        {currentView === 'submit' && (
          <SubmitView
            initialChallengeTitle={submitChallengeTitle}
            onToast={(msg) => setToastMessage(msg)}
          />
        )}

        {currentView === 'about' && (
          <AboutView
            settings={settings}
            onNavigate={handleNavigate}
          />
        )}

        {currentView === 'contact' && (
          <ContactView
            settings={settings}
            onToast={(msg) => setToastMessage(msg)}
          />
        )}

        {currentView === 'admin' && !currentUser && (
          <AdminLoginView
            onLoginSuccess={handleLoginSuccess}
            onBackToHome={() => handleNavigate('home')}
          />
        )}
      </main>

      {/* Global Footer */}
      <Footer
        onNavigate={handleNavigate}
        settings={settings}
        onOpenAdminLogin={() => {
          if (currentUser) {
            setCurrentView('admin');
          } else {
            setIsAdminLoginOpen(true);
          }
        }}
      />

      {/* Modals & Overlays */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        articles={articles.filter(a => a.status === 'Published')}
        opportunities={opportunities.filter(o => o.status === 'Verified/Open' || o.status === 'Closing Soon')}
        resources={resources.filter(r => r.status === 'Published')}
        challenges={challenges.filter(c => c.status === 'Active')}
        onSelectResult={handleSearchResult}
      />

      <ReportModal
        isOpen={reportModalData.isOpen}
        onClose={() => setReportModalData(prev => ({ ...prev, isOpen: false }))}
        targetType={reportModalData.type}
        targetId={reportModalData.id}
        targetTitle={reportModalData.title}
        onSuccessToast={(msg) => setToastMessage(msg)}
      />

      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => setIsAdminLoginOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      <NotificationToast
        message={toastMessage}
        onClose={() => setToastMessage(null)}
      />

    </div>
  );
}
